import React from 'react'

const History = () => {
  return (
    <div>History [추후 추가될 예정]</div>
  )
}

export default History