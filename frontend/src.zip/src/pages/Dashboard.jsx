import React, { useState } from 'react'
import { useNavigate, useOutletContext } from 'react-router-dom'
import styled from 'styled-components'
import { Card, Avatar, Typography, Row, Col, Button, Checkbox, List, Badge } from 'antd'
import { UserOutlined, PlusOutlined } from '@ant-design/icons'
import { Calendar as AntdCalendar } from 'antd'
import styles from './css_folder/Dashboard.module.css'
import dayjs from 'dayjs'

const { Title, Text } = Typography

const initialTodoData = [
  { text: '명세서 제출하기', checked: true },
  { text: '테스트 계획서 제출하기', checked: true },
  { text: '인강 듣기', checked: true },
  { text: '자격증 공부', checked: true },
]

const Dashboard = () => {
  const { projectList } = useOutletContext(); // RootLayout에서 전달한 프로젝트 목록
  const navigate = useNavigate()

  const getRandomImageUrl = () => {
    return `https://picsum.photos/seed/${Math.floor(Math.random() * 99999)}/400/200`
  }

  const [todoList, setTodoList] = useState(initialTodoData)
  const [calendarValue, setCalendarValue] = useState(dayjs())
  const [creatNewProjectModal, setcreatNewProjectModal] = useState(false)
  const [newProjectName, setNewProjectName] = useState('')
  const [newProjectArticle, setNewProjectArticle] = useState('')

  const onCheck = (idx) => {
    setTodoList(list =>
      list.map((item, i) =>
        i === idx ? { ...item, checked: !item.checked } : item
      )
    )
  }

  return (
    <MainContainer>
      <RowBox>
        <ProfileCardWrapper bodyStyle={{ display: 'flex', flexDirection: 'row', height: '100%', padding: 0 }}>
          <ProfileLeft>
            <Avatar size={140} icon={<UserOutlined />} style={{ marginBottom: 8, background: '#f5f5f5', boxShadow: '0 8px 24px 0 rgba(31,38,135,0.10)' }} />
            <ProfileName>Wiffle</ProfileName>
            <ProfileJob>UI/UX 디자이너</ProfileJob>
          </ProfileLeft>
          <ProfileRight>
            <ProfileInfoTitle>Profile Information</ProfileInfoTitle>
            <ProfileDesc>
              안녕하세요 저는 초보 디자이너 입니다.<br />
              웹 사이트 기본 제작 경험 보유
            </ProfileDesc>
            <ProfileLine />
            <ProfileInfoList>
              <span>Name:</span> wiffle<br />
              <span>Phone:</span> (82) 010 1234 5678<br />
              <span>Email:</span> wiffle@gmail.com
            </ProfileInfoList>
          </ProfileRight>
        </ProfileCardWrapper>

        <Col flex="4" className={styles.calendarWrapper}>
          <div className={styles.customCalendar}>
            <AntdCalendar
              fullscreen={false}
              value={calendarValue}
              onChange={(newValue) => setCalendarValue(dayjs(newValue))}
              headerRender={({ value, onChange }) => (
                <div className={styles.calendarHeader}>
                  <Button className={styles.calendarNavButton} onClick={() => onChange(value.subtract(1, 'month'))}>{'<'}</Button>
                  <span className={styles.calendarTitle}>{value.format('MMMM, YYYY')}</span>
                  <Button className={styles.calendarNavButton} onClick={() => onChange(value.add(1, 'month'))}>{'>'}</Button>
                </div>
              )}
            />
          </div>
        </Col>
      </RowBox>

      <RowBox>
        <Col flex="3">
          <Card className={styles.todoCard} bodyStyle={{ padding: 0, height: '100%' }}>
            <div className={styles.todoHeader}>
              <span className={styles.todoTitle}>
                TODAY - TASK
                <Badge count={todoList.length} className={styles.todoBadge} />
              </span>
            </div>

            <div className={styles.todoScrollBox}>
              <List
                dataSource={todoList}
                renderItem={(item, idx) => (
                  <List.Item className={styles.todoItem}>
                    <Checkbox checked={item.checked} onChange={() => onCheck(idx)} className={styles.todoCheckbox}>
                      <span className={item.checked ? styles.todoTextChecked : styles.todoText}>
                        {item.text}
                      </span>
                    </Checkbox>
                  </List.Item>
                )}
              />
            </div>
          </Card>
        </Col>

        <Col flex="7">
          <Card
            className={styles.projectCard}
            title={
              <span className={styles.projectTitle}>
                Projects <span className={styles.projectSubtitle}>Architects design houses</span>
              </span>
            }
            bodyStyle={{ padding: 24 }}
          >
            <div className={styles.projectScrollWrapper}>
              <div className={styles.projectCardItem} onClick={() => setcreatNewProjectModal(true)}>
                <Card hoverable className={styles.emptyProjectCard} bodyStyle={{ height: 120 }}>
                  <PlusOutlined />
                </Card>
              </div>

              {projectList.map((project, idx) => (
                <div key={idx} className={styles.projectCardItem}>
                  <Card
                    hoverable
                    cover={<img alt={project.project_name} src={project.img || getRandomImageUrl()} className={styles.projectImage} />}
                    className={styles.projectItem}
                    bodyStyle={{ padding: 16, display: 'flex', flexDirection: 'column', flexGrow: 1, justifyContent: 'space-between' }}
                  >
                    <Title level={5} style={{ margin: 0 }}>{project.project_name}</Title>
                    <Text className={styles.projectDesc}>{project.description}</Text>
                    <div className={styles.cardButtonWrapper}>
                      <Button size="small" type="primary" style={{ textAlign: 'center', fontSize: '0.75rem', padding: '10px' }}
                        onClick={() => {
                          navigate(`/project/${project.project_id}`, {
                            state: { project }
                          });
                        }}
                      >
                        VIEW ALL
                      </Button>
                    </div>
                  </Card>
                </div>
              ))}
            </div>
          </Card>
        </Col>
      </RowBox>

      {/* 프로젝트 추가 모달 (기존 상태 유지) */}
      {creatNewProjectModal && (
        <div className={styles.modalOverlay}>
          <div className={styles.modalContent_0}>
            <h2>프로젝트 추가</h2>
            <hr />
            <label htmlFor="project_title">제목: </label> <br />
            <input
              type="text"
              id="project_title"
              placeholder="프로젝트 이름 입력"
              value={newProjectName}
              onChange={(e) => setNewProjectName(e.target.value)}
            /> <br />

            <label htmlFor="project_content">내용: </label> <br />
            <textarea
              id="project_content"
              className={styles.textareaInput}
              placeholder="프로젝트 개요 입력"
              value={newProjectArticle}
              onChange={(e) => setNewProjectArticle(e.target.value)}
            /> <br />

            <label htmlFor="project_writer">작성자: </label> <br />
            <input
              type="text"
              id="project_writer"
              value="작성자 정보 필요"
              readOnly
            /> <br />

            <div className={styles.modalButtonWrapper} style={{ marginTop: '1.5rem' }}>
              <button
                id={styles.confirmButton}
                onClick={() => {
                  // 임시 추가 로직 (실제 백엔드 연동 필요)
                  const newProject = {
                    title: newProjectName.trim(),
                    desc: newProjectArticle,
                    img: getRandomImageUrl(),
                    members: 0
                  };
                  console.log('새 프로젝트 생성 (임시)', newProject);
                  setNewProjectName('');
                  setNewProjectArticle('');
                  setcreatNewProjectModal(false);
                }}
              >
                추가
              </button>
              <button
                id={styles.cancelButton}
                onClick={() => {
                  setNewProjectName('');
                  setNewProjectArticle('');
                  setcreatNewProjectModal(false);
                }}
              >
                취소
              </button>
            </div>
          </div>
        </div>
      )}
    </MainContainer>
  )
}

export default Dashboard;

const MainContainer = styled.div`
  width: 100%;
  min-height: 100vh;
  background: #fff;
`

const RowBox = styled.div`
  width: 100%;
  display: flex;
  flex-direction: row;
  gap: 16px;
`

const ProfileCardWrapper = styled(Card)`
  display: flex;
  justify-content: center;         /* 콘텐츠 가운데 */
  align-items: center;             /* 수직 가운데 */
  max-width: 1100px;
  width: 65%;
  height: 340px;
  padding: 0 !important;
  border-radius: 28px !important;
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.10) !important;
  background: #fff !important;
  border: none !important;
  margin-bottom: 32px;
`

const ProfileLeft = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  margin: auto 165px auto auto; /* 왼쪽 여백 없음, 오른쪽 여백 있음 */
  width: 260px;
  height: 100%;
`

const ProfileRight = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-right: 160px;
`

const ProfileName = styled.div`
  font-size: 28px;
  font-weight: 700;
  color: #222;
  margin-top: 18px;
  margin-bottom: 0;
`

const ProfileJob = styled.div`
  font-size: 16px;
  color: #888;
  margin-bottom: 18px;
`

const ProfileInfoTitle = styled.div`
  font-size: 20px;
  font-weight: 700;
  margin-bottom: 10px;
  color: #222;
`

const ProfileDesc = styled.div`
  color: #222;
  font-size: 15px;
  margin-bottom: 12px;
  line-height: 1.5;
`

const ProfileLine = styled.div`
  width: 100%;
  height: 1px;
  background: #e5e5e5;
  margin: 10px 0 16px 0;
`

const ProfileInfoList = styled.div`
  font-size: 15px;
  color: #222;
  line-height: 2;
  span {
    font-weight: 700;
    margin-right: 8px;
  }
`