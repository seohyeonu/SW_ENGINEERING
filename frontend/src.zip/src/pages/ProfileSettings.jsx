import React, { useState } from 'react'
import styles from './css_folder/ProfileSettings.module.css'

const ProfileSettingsModal = ({ visible, onClose, onSave, user }) => {
  const [isEditing, setIsEditing] = useState(false)
  const [isPasswordEditing, setIsPasswordEditing] = useState(false)
  const [showVerifyModal, setShowVerifyModal] = useState(false)

  const [name, setName] = useState(user?.name || '홍길동')
  const [username, setUsername] = useState(user?.username || 'hong123')
  const [email, setEmail] = useState(user?.email || 'hong@example.com')
  const [phone, setPhone] = useState(user?.phone || '010-1234-5678')
  const [department, setDepartment] = useState(user?.department || '기획팀')
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState('')

  const handleSave = () => {
    if (isPasswordEditing && newPassword && newPassword !== confirmPassword) {
      setError('비밀번호가 일치하지 않습니다.')
      return
    }
    setError('')
    onSave({ name, username, email, phone, department, currentPassword, newPassword })
    setIsEditing(false)
    setIsPasswordEditing(false)
  }

  const handleVerifyPassword = () => {
    if (currentPassword === '1234') { // 가짜 검증 로직
      setIsPasswordEditing(true)
      setShowVerifyModal(false)
      setCurrentPassword('')
    } else {
      setError('현재 비밀번호가 올바르지 않습니다.')
    }
  }

  if (!visible) return null

  return (
    <div className={styles.modalOverlay}>
      <div className={styles.modalContent}>
        <h2>프로필 설정</h2>
        <hr />

        <label htmlFor="name">이름</label>
        <input id="name" type="text" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} readOnly={!isEditing} />

        <label htmlFor="username">아이디</label>
        <input id="username" type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} readOnly={!isEditing} />

        <label htmlFor="email">이메일</label>
        <input id="email" type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} readOnly={!isEditing} />

        <label htmlFor="phone">전화번호</label>
        <input id="phone" type="tel" placeholder="010-0000-0000" value={phone} onChange={(e) => setPhone(e.target.value)} readOnly={!isEditing} />

        <label htmlFor="department">부서</label>
        <input id="department" type="text" placeholder="Department" value={department} onChange={(e) => setDepartment(e.target.value)} readOnly={!isEditing} />

        {isPasswordEditing && (
          <>
            <label htmlFor="newPassword">새 비밀번호</label>
            <input id="newPassword" type="password" placeholder="새 비밀번호" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
            <label htmlFor="confirmPassword">비밀번호 확인</label>
            <input id="confirmPassword" type="password" placeholder="비밀번호 확인" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
          </>
        )}

        {error && <p className={styles.errorText}>{error}</p>}

        <div className={styles.modalButtonWrapper}>
          {isEditing ? (
            <>
              <button className={styles.confirmButton} onClick={handleSave}>저장</button>
              <button className={styles.cancelButton} onClick={() => {
                setIsEditing(false);
                setIsPasswordEditing(false);
                setCurrentPassword('');
                setNewPassword('');
                setConfirmPassword('');
                setError('');
              }}>취소</button>
              {!isPasswordEditing && (
                <button className={styles.confirmButton} onClick={() => {
                  setShowVerifyModal(true)
                  setCurrentPassword('')
                }}>비밀번호 변경</button>
              )}
            </>
          ) : (
            <>
              <button className={styles.confirmButton} onClick={() => setIsEditing(true)}>수정하기</button>
              <button className={styles.cancelButton} onClick={onClose}>닫기</button>
            </>
          )}
        </div>
      </div>

      {showVerifyModal && (
        <div className={styles.modalOverlay}>
          <div className={styles.modalContent}>
            <h3>비밀번호 확인</h3>
            <input
              type="password"
              placeholder="현재 비밀번호 입력"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
            />
            <div className={styles.modalButtonWrapper}>
              <button className={styles.confirmButton} onClick={handleVerifyPassword}>확인</button>
              <button className={styles.cancelButton} onClick={() => setShowVerifyModal(false)}>취소</button>
            </div>
            {error && <p className={styles.errorText}>{error}</p>}
          </div>
        </div>
      )}
    </div>
  )
}

export default ProfileSettingsModal